<?php
include (dirname(dirname(dirname(dirname(dirname(dirname(dirname(__FILE__))))))) . '/wp-load.php');

global $wpdb;

if(isset($_POST['action']) && $_POST['action']=='enroll_register'){
	global $wpdb;
	$stu_fname = $_POST['stu_first_name']; 
	$stu_lname = $_POST['stu_last_name']; 
	$stu_datebirth = $_POST['daterange']; 
	$stu_email = $_POST['stu_email']; 
	$stu_phone = $_POST['stu_phone']; 
	$stu_gender = $_POST['stu_gender']; 
	$stu_address = $_POST['stu_address']; 
	/* $stu_course = $_POST['stu_class']; 
	$stu_teacher = $_POST['stu_teacher'];  */
	
	$parent_firstname = $_POST['par_firstname']; 
	$parent_lastname = $_POST['par_lastname']; 
	$parent_email = $_POST['par_email']; 
	$parent_phone = $_POST['par_phone']; 
	$parent_address = $_POST['par_address']; 
	$parent_relationship = $_POST['par_relationship']; 
	
	$random_val = rand(20,100);
	
	/* $post_name   = get_post( $stu_course );
	$course_name = $post_name->post_name; */
	
	$student_fullname = strtolower($stu_fname."_".$stu_lname);
	$parent_fullname = strtolower($parent_firstname."_".$parent_lastname);
	
	/* $ss_id = '22';
	
	echo "<pre>";print_r(serialize(array(str_replace("","",$ss_id))));
	die(); */
	$parentdata = array(
    'user_login'             => $parent_fullname, 
    'user_pass'            => md5('/){:}('.$parent_fullname),
    'user_nicename'         => $parent_fullname,
    'user_email'            => $parent_email,
    'display_name'          => $parent_fullname,
    'first_name'          => $parent_firstname,
    'last_name'          => $parent_lastname
	);
	$parent_id = wp_insert_user( $parentdata ) ;
	

	add_user_meta($parent_id,'parent_firstname',$parent_firstname);
	add_user_meta($parent_id,'parent_lastname',$parent_lastname);
	add_user_meta($parent_id,'parent_phone',$parent_phone);
	add_user_meta($parent_id,'parent_address',$parent_address);
	add_user_meta($parent_id,'parent_relationship',$parent_relationship);
	/* add_user_meta($parent_id,'course_id',$stu_course);
	add_user_meta($parent_id,'course_name',$course_name); */
	
	
	$studentdata = array(
    'user_login'             => $student_fullname,
    'user_pass'            => md5('/){:}('.$student_fullname),
    'user_nicename'         => $student_fullname,
    'user_email'            => $stu_email,
    'display_name'          => $student_fullname,
    'first_name'          => $stu_fname,
    'last_name'          => $stu_lname
	);
	$student_id = wp_insert_user( $studentdata );
	
	add_user_meta($student_id,'student_firstname',$stu_fname);
	add_user_meta($student_id,'student_lastname',$stu_lname);
	add_user_meta($student_id,'student_gender',$stu_gender);
	add_user_meta($student_id,'student_birthdate',$stu_datebirth);
	add_user_meta($student_id,'student_phone',$stu_phone);
	add_user_meta($student_id,'student_address',$stu_address);
	add_user_meta($student_id,'parent_id',$parent_id);
	add_user_meta($student_id,'student_relation_ship',$parent_relationship);
	/* add_user_meta($student_id,'student_course_id',$stu_course);
	add_user_meta($student_id,'student_teacher_id',$stu_teacher); */
	
	/** Create Group **/
	
	/* $parent_id = '31';
	$student_id = '32'; */
	
	if(!empty($student_id)){
		/* $group_create = array(
		  'post_title'    => $course_name."_".$student_fullname ,
		  'post_content'  => '',
		  'post_status'   => 'publish',
		  'post_type'   => 'groups'
		);
		 
		
		$group_id = wp_insert_post( $group_create ); */
		
	/** Add group to teacher **/
		/* add_user_meta($stu_teacher,'learndash_group_leaders_'.$group_id,$group_id); */
	
	/** Assign group to user **/	
		/* add_user_meta($student_id,'learndash_group_users_'.$group_id,$group_id); */
		
		
	/** Assign Course to group **/	
		/* add_post_meta($stu_course,'learndash_group_enrolled_'.$group_id,strtotime("now")); */
		
		
	/** add term (Assign role to user student)**/
		
		$get_term_role = $wpdb->get_results("select * from ".$wpdb->prefix."terms where name='student'");
		$term_id = $get_term_role[0]->term_id;
		
		$get_term_texomony = $wpdb->get_results("select * from ".$wpdb->prefix."term_taxonomy where term_id='".$term_id."'");
		$total_cnt = $get_term_texomony[0]->count+1;
		
		if(sizeof($get_term_texomony)>0){
			$update_term_taxonomy = $wpdb->query("UPDATE ".$wpdb->prefix."term_taxonomy set count='".$total_cnt."' where term_taxonomy_id='".$get_term_texomony[0]->term_taxonomy_id."'");
			$term_taxo = $get_term_texomony[0]->term_taxonomy_id;
			
		}else{
			$insert_term = $wpdb->query("INSERT INTO ".$wpdb->prefix."term_taxonomy (term_taxonomy_id,term_id,taxonomy,description,parent,count) values( '','".$term_id."','bp_member_type','','1')");
			
			$term_taxo = $insert_term->term_taxonomy_id;
		}
		/* echo 'here'."</br>"; */
		 $insert_term_relationships = $wpdb->query("INSERT INTO ".$wpdb->prefix."term_relationships (object_id,term_taxonomy_id,term_order) values( '".$student_id."','".$term_taxo."','')"); 
		
	}
	if(!empty($parent_id)){
		
		
	/** add term (Assign role to user parent**/
	
	$get_term_role_par = $wpdb->get_results("select * from ".$wpdb->prefix."terms where name='parent'");
		$term_id_par = $get_term_role_par[0]->term_id;
		
		$get_term_texomony_par = $wpdb->get_results("select * from ".$wpdb->prefix."term_taxonomy where term_id='".$term_id_par."'");
		$total_cnt_par = $get_term_texomony_par[0]->count+1;
		
		if(sizeof($get_term_texomony_par)>0){
			$update_term_taxonomy = $wpdb->query("UPDATE ".$wpdb->prefix."term_taxonomy set count='".$total_cnt_par."' term_taxonomy_id='".$get_term_texomony_par[0]->term_taxonomy_id."'");
			$term_taxo_par = $get_term_texomony_par[0]->term_taxonomy_id;
		}else{
			$insert_term_par = $wpdb->query("INSERT INTO ".$wpdb->prefix."term_taxonomy (term_taxonomy_id,term_id,taxonomy,description,parent,count) values( '','".$term_id_par."','bp_member_type','','1')");
			
			$term_taxo_par = $insert_term_par->term_taxonomy_id;
		}
		
		$insert_term_relationships = $wpdb->query("INSERT INTO ".$wpdb->prefix."term_relationships (object_id,term_taxonomy_id,term_order) values( '".$parent_id."','".$term_taxo_par."','')");  
	
		/**Update status of enroll to no **/
		
		
	}
	if(!empty($_POST['hid_enrollment_id'])){
		$update_enrollment_form = $wpdb->query("UPDATE ".$wpdb->prefix."ss_enrollment_form set status='yes' where id='".$_POST['hid_enrollment_id']."'");
		}
	die();
}


if(isset($_POST['action']) && $_POST['action'] == 'update_registered_user'){
	global $wpdb;
	$user_id = $_POST['user_id'];
	$student_registered_fname = $_POST['student_registered_fname'];
	$student_registered_lname = $_POST['student_registered_lname'];
	$student_registered_email = $_POST['student_registered_email'];
	$student_registered_gender = $_POST['student_registered_gender'];
	$student_registered_phone = $_POST['student_registered_phone'];
	$student_registered_address = $_POST['student_registered_address'];
	
	if(!empty($user_id)){
		$user_table = wp_update_user( array( 'ID' => $user_id, 'user_email' => $student_registered_email ) );
		
		update_user_meta($user_id,'first_name',$student_registered_fname);
		update_user_meta($user_id,'last_name',$student_registered_lname);
		update_user_meta($user_id,'student_gender',$student_registered_gender);
		update_user_meta($user_id,'student_phone',$student_registered_phone);
		update_user_meta($user_id,'student_address',$student_registered_address);
	}
	die();
}

if(isset($_POST['action']) && $_POST['action'] == 'update_par_registered_user'){
	global $wpdb;
	$user_id = $_POST['user_id'];
	$par_registered_fname = $_POST['par_registered_fname'];
	$par_registered_lname = $_POST['par_registered_lname'];
	$par_registered_email = $_POST['par_registered_email'];
	$par_registered_phone = $_POST['par_registered_phone'];
	$par_registered_address = $_POST['par_registered_address'];
	
	if(!empty($user_id)){
		$user_table = wp_update_user( array( 'ID' => $user_id, 'user_email' => $par_registered_email ) );
		
		update_user_meta($user_id,'first_name',$par_registered_fname);
		update_user_meta($user_id,'last_name',$par_registered_lname);
		update_user_meta($user_id,'parent_phone',$par_registered_phone);
		update_user_meta($user_id,'parent_address',$par_registered_address);
	}
	die();
}

?>