<?php
/* include (dirname(dirname(dirname(dirname(dirname(__FILE__))))) . '/wp-load.php'); */
if(isset($_POST['admission_submit_button'])){
	
	$student_firstname = $_POST['stu_first_name'];
	$student_lastname = $_POST['stu_last_name'];
	$student_birthdate = $_POST['daterange'];
	$student_email = $_POST['stu_email'];
	$student_phone = $_POST['stu_phone'];
	$student_gender = $_POST['stu_gender'];
	$student_username = $_POST['stu_username'];
	$student_password = $_POST['stu_password'];
	$student_address = $_POST['stu_address'];
	$student_rollid = $_POST['stu_rollid'];
	$student_class = $_POST['stu_class'];
	$student_section = $_POST['stu_section'];
	$student_school_bus = $_POST['stu_school_bus'];
	$student_class_room = $_POST['stu_class_room'];
	
	
	$parent_firstname = $_POST['par_firstname'];
	$parent_lastname = $_POST['par_lastname'];
	$parent_gender = $_POST['par_gender'];
	$parent_email = $_POST['par_email'];
	$parent_username = $_POST['par_username'];
	$parent_password = $_POST['par_password'];
	$parent_phone = $_POST['par_phone'];
	$parent_personal_doc = $_POST['par_personal_doc'];
	$parent_profession = $_POST['par_profession'];
	$parent_address = $_POST['par_address'];
	$parent_home_phone = $_POST['par_home_phone'];
	$parent_workplace = $_POST['par_workplace'];
	$parent_workphone = $_POST['par_workphone'];
	
	
	$cpd_con_diseases = $_POST['cpd_con_diseases'];
	$cpd_allergies = $_POST['cpd_allergies'];
	$cpd_personal_doctor = $_POST['cpd_personal_doctor'];
	$cpd_doctor_phone = $_POST['cpd_doctor_phone'];
	$cpd_authorized_person = $_POST['cpd_authorized_person'];
	$cpd_person_phone = $_POST['cpd_authorized_person_phone'];
	$cpd_notes = $_POST['cpd_notes'];
	
	
	/** Insert parent and parent Details **/
	/* $parentdata = array(
    'user_login'             => $parent_username,
    'user_pass'            => md5($parent_password),
    'user_nicename'         => $parent_username,
    'user_email'            => $parent_email,
    'display_name'          => $parent_username
	);
	$parent_id = wp_insert_user( $parentdata ) ;
	
	add_user_meta($parent_id,'parent_firstname',$parent_firstname);
	add_user_meta($parent_id,'parent_lastname',$parent_lastname);
	add_user_meta($parent_id,'parent_phone',$parent_phone);
	add_user_meta($parent_id,'parent_gender',$parent_gender);
	add_user_meta($parent_id,'parent_address',$parent_address);
	add_user_meta($parent_id,'parent_personal_doc',$parent_personal_doc);
	add_user_meta($parent_id,'parent_profession',$parent_profession);
	add_user_meta($parent_id,'parent_home_phone',$parent_home_phone);
	add_user_meta($parent_id,'parent_workplace',$parent_workplace);
	add_user_meta($parent_id,'parent_workphone',$parent_workphone); */
	
	/** Insert Student and Student Details **/
	/* $studentdata = array(
    'user_login'             => $student_username,
    'user_pass'            => md5($student_password),
    'user_nicename'         => $student_username,
    'user_email'            => $student_email,
    'display_name'          => $student_username
	);
	$student_id = wp_insert_user( $studentdata ) ;
	
	add_user_meta($student_id,'student_firstname',$student_firstname);
	add_user_meta($student_id,'student_lastname',$student_lastname);
	add_user_meta($student_id,'student_birthdate',$student_birthdate);
	add_user_meta($student_id,'student_phone',$student_phone);
	add_user_meta($student_id,'student_gender',$student_gender);
	add_user_meta($student_id,'student_address',$student_address);
	add_user_meta($student_id,'student_rollid',$student_rollid);
	add_user_meta($student_id,'student_class',$student_class);
	add_user_meta($student_id,'student_section',$student_section);
	add_user_meta($student_id,'student_school_bus',$student_school_bus);
	add_user_meta($student_id,'student_class_room',$student_class_room);
	add_user_meta($student_id,'student_parent_id',$parent_id); */
	
	
	die();
}
?>