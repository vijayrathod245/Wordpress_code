jQuery(document).ready(function(){
	var ajax_path = ajax_root.ajax_anchor;
	var dashboard_path = dashboard_root.dashboard_anchor;
	jQuery("#form_registration").submit(function(event){
        event.preventDefault(); 
		/* alert(''); */
        var formData = new FormData(this);
		formData.append('action','enroll_register');
		/* var post_data = {formData:formData,action:'register'} */
          jQuery.ajax({
             url: ajax_path,
             type: 'POST',
             data: formData,
             async: false,
             success: function(data) {
               window.location.href = dashboard_path;
            },
            cache: false,
            contentType: false,
            processData: false
        });
     });	
});


jQuery(document).ready(function(){
	jQuery('.update_registered_button').on('click',function(){
		
		var ajax_path = ajax_root.ajax_anchor;
		
		var user_id = jQuery(this).data('id');
		var student_registered_fname = jQuery('.student_registered_fname'+user_id).val();
		var student_registered_lname = jQuery('.student_registered_lname'+user_id).val();
		var student_registered_email = jQuery('.student_registered_email'+user_id).val();
		var student_registered_gender = jQuery('.student_registered_gender'+user_id).val();
		var student_registered_phone = jQuery('.student_registered_phone'+user_id).val();
		var student_registered_address = jQuery('.student_registered_address'+user_id).val();
		var postdata = {user_id:user_id,student_registered_fname:student_registered_fname,student_registered_lname:student_registered_lname,student_registered_email:student_registered_email,student_registered_gender:student_registered_gender,student_registered_phone:student_registered_phone,student_registered_address:student_registered_address,action:'update_registered_user'};
			jQuery.ajax({					
					url  : ajax_path,					
					type : 'POST',					
					data : postdata,					
					dataType : 'html',					
					success  : function(response) {
						location.reload();
					}
			});
	
	
});
});

jQuery(document).ready(function(){
	jQuery('.update_par_registered_button').on('click',function(){
		
		var ajax_path = ajax_root.ajax_anchor;
		
		var user_id = jQuery(this).data('id');
		var par_registered_fname = jQuery('.par_registered_fname'+user_id).val();
		var par_registered_lname = jQuery('.par_registered_lname'+user_id).val();
		var par_registered_email = jQuery('.par_registered_email'+user_id).val();
		var par_registered_phone = jQuery('.par_registered_phone'+user_id).val();
		var par_registered_address = jQuery('.par_registered_address'+user_id).val();
		var postdata = {user_id:user_id,par_registered_fname:par_registered_fname,par_registered_lname:par_registered_lname,par_registered_email:par_registered_email,par_registered_phone:par_registered_phone,par_registered_address:par_registered_address,action:'update_par_registered_user'};
			jQuery.ajax({					
					url  : ajax_path,					
					type : 'POST',					
					data : postdata,					
					dataType : 'html',					
					success  : function(response) {
						location.reload();
					}
			});
	
	
});
});

jQuery(document).ready(function(){
	jQuery('.new_trial_teacher').on('change',function(){
		
		var ajax_path = ajax_root.ajax_anchor;
		
		alert(jQuery(this).val());
		/* var postdata = {user_id:user_id,par_registered_fname:par_registered_fname,par_registered_lname:par_registered_lname,par_registered_email:par_registered_email,par_registered_phone:par_registered_phone,par_registered_address:par_registered_address,action:'update_par_registered_user'};
			jQuery.ajax({					
					url  : ajax_path,					
					type : 'POST',					
					data : postdata,					
					dataType : 'html',					
					success  : function(response) {
						location.reload();
					}
			}); */
	
	
	});
});
