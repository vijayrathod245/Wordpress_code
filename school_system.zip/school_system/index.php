<?php
/**
 * Plugin Name:       School System
 * Plugin URI:        https://wordpress.org
 * Description:       School System
 * Version:           1.0
 * Author:            BI
 * Author URI:        #
 * License:           #
 * License URI:       #
 */


function front_enrollment_form(){
	ob_start();
	$plugin_name =  plugin_basename(dirname( __FILE__ ));
	$plugin_path =  plugins_url().'/'.$plugin_name;
	include(dirname(__FILE__).'/dashboards/shortcodes/enrollment_shortcode.php');
	$op = ob_get_clean();
	return $op;
}
add_shortcode( 'enrollment_form', 'front_enrollment_form' );

function my_login_redirect( $url, $request, $user ) {	
	global $user;	
	$current_user_id = $user->ID;	
	$plugin_name =  plugin_basename(dirname( __FILE__ ));
	$plugin_path =  plugins_url().'/'.$plugin_name;
		if(!empty(wp_get_object_terms($current_user_id,'bp_member_type')) && $current_user_id!==1)
		{		
			$role = wp_get_object_terms($current_user_id,'bp_member_type')[0]->name;		
		
			if($role == 'parent' || $role == 'Parent' || $role == 'parents' || $role == 'Parents'){	
				wp_redirect(site_url()."/wp-content/plugins/login/includes/parent.php");	
				exit;		
			}elseif($role == 'student' || $role == 'Student'){	
				wp_redirect($plugin_path."/dashboards/student/student.php");		
				exit;		
			}elseif($role == 'staff'){		
				wp_redirect($plugin_path."/dashboards/staff_admin/staff.php");	
				exit;		
			}elseif($role == 'teacher'){	
				wp_redirect($plugin_path."/dashboards/teacher/teacher.php");		
				exit;		
			}elseif($role == 'support'){			
				wp_redirect($plugin_path."/dashboards/support/support.php");		
				exit;		
			}elseif($role == 'school-admin'){					
				wp_redirect($plugin_path."/dashboards/school_admin/school_admin.php");		
				exit;		
			}	
		}	
	return $url;
}
add_filter( 'login_redirect', 'my_login_redirect', 10, 3 );