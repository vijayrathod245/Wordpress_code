<link rel="stylesheet" href="<?php echo $plugin_path;?>/assets/css/bootstrap.css">
<link rel="stylesheet" href="<?php echo $plugin_path;?>/assets/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo $plugin_path;?>/assets/css/style.css">
<link rel="stylesheet" href="<?php echo $plugin_path;?>/assets/css/common.css">
<link rel="stylesheet" href="<?php echo $plugin_path;?>/assets/css/responsive.css">
<link rel="stylesheet" href="<?php echo $plugin_path;?>/assets/css/fontawesome.min.css">
<link rel="stylesheet" href="<?php echo $plugin_path;?>/assets/css/font.css">
<link rel="stylesheet" href="<?php echo $plugin_path;?>/assets/css/all.min.css">
<link rel="stylesheet" href="<?php echo $plugin_path;?>/assets/css/gijgo.min.css">

   <link rel="stylesheet" href="<?php echo $plugin_path;?>/assets/css/staff-style.css">
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap.min.css">
<link href="https://cdn.datatables.net/fixedheader/3.1.6/css/fixedHeader.bootstrap.min.css">
<link href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.bootstrap.min.css">