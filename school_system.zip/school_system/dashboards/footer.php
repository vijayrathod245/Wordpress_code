<script src="<?php echo $plugin_path;?>/assets/js/jquery.min.js"></script> 
<script src="<?php echo $plugin_path;?>/assets/js/bootstrap.js"> </script>
<script src="<?php echo $plugin_path;?>/assets/js/bootstrap.min.js"></script>
<script src="<?php echo $plugin_path;?>/assets/js/all.min.js"></script>
<script src="<?php echo $plugin_path;?>/assets/js/fontawesome.min.js"></script>
<script src="<?php echo $plugin_path;?>/assets/js/gijgo.min.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>
