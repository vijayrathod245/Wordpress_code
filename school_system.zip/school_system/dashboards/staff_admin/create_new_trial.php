<?php 
include (dirname(dirname(dirname(dirname(dirname(dirname(__FILE__)))))) . '/wp-load.php');

$plugin_name =  plugin_basename(dirname(dirname(dirname( __FILE__ ))));
$plugin_path =  plugins_url().'/'.$plugin_name;

include(dirname(dirname(__FILE__)).'/header.php');

global $wpdb;
if(isset($_POST['create_class_button'])){
	global $wpdb;
	$create_class_name = $_POST['create_class_name'];
	$create_class_teacher = $_POST['create_class_teacher'];
	$start_class_date = date('Y-m-d');
	$create_class_time = $_POST['create_class_time'];
	$create_class_duration = $_POST['create_class_duration'];
	
	$insert_class = $wpdb->query("insert into ".$wpdb->prefix."class (id,class_name,class_teacher,class_date,class_time,class_duration) values('','".$create_class_name."','".$create_class_teacher."','".$start_class_date."','".$create_class_time."','".$create_class_duration."')");
		
	/* $wpdb->query("INSERT INTO ".$wpdb->prefix."term_taxonomy (term_taxonomy_id,term_id,taxonomy,description,parent,count) values( '','".$term_id_par."','bp_member_type','','1')");	 */
}

?>
    <!DOCTYPE html>
    <html>

    <head>
        <title>Staff Admin</title>
        
		<?php ?>
    </head>
    <body>
        <div>
            <h1>Staff</h1></div>
        <div class="container">
		<form method="post">
		<input type="hidden" name="hid_enrollment_id" value="<?php echo $_REQUEST['enroll_id'];?>"/>
            <div class="student_form">
                <div class="row">
                    <h1>Add Class</h1>
                    <div style="width:100%;">
					
						
                        
                            
								
							<div class="form-group">
							<label for="formGroupExampleInput">Select Teacher</label>
							<select class="form-control new_trial_teacher" name="new_trial_teacher" id="new_trial_teacher">
								<option>Select Teacher</option>
								<?php
								$get_term_role = $wpdb->get_results("select * from ".$wpdb->prefix."terms where name='teacher'");
								$term_id = $get_term_role[0]->term_id;
								$get_term_texomony = $wpdb->get_results("select * from ".$wpdb->prefix."term_taxonomy where term_id='".$term_id."'");
								$term_texonomy_id = $get_term_texomony[0]->term_taxonomy_id;
								$get_term_relationship = $wpdb->get_results("select * from ".$wpdb->prefix."term_relationships where term_taxonomy_id='".$term_texonomy_id."'");
								foreach($get_term_relationship as $term_relation_object_id){
										$object_id = $term_relation_object_id->object_id;
										
										$user = get_userdata( $object_id );
										$user_id = $user->ID;
										if(!empty($user_id)){
										$user_fullname = get_user_meta($user_id)['first_name'][0]." ".get_user_meta($user_id)['last_name'][0];
										?>
										<option value="<?php echo $user_id;?>"><?php echo $user_fullname;?></option>
										<?php
										}
									}
								?>
							</select>
						
							</div> 
							<div class="form-group">
							<label for="formGroupExampleInput">Select Class</label>
                                <select class="form-control" name="new_trial_class" id="new_trial_class">
								<option>Select Class</option>
								
								</select>
							</div>
                           <div class="form-group">
							<label for="formGroupExampleInput">Select Student</label>
							<select class="form-control" name="new_trial_student" id="new_trial_student">
								<option>Select Student</option>
								<?php
								$get_term_role = $wpdb->get_results("select * from ".$wpdb->prefix."terms where name='student'");
								$term_id = $get_term_role[0]->term_id;
								$get_term_texomony = $wpdb->get_results("select * from ".$wpdb->prefix."term_taxonomy where term_id='".$term_id."'");
								$term_texonomy_id = $get_term_texomony[0]->term_taxonomy_id;
								$get_term_relationship = $wpdb->get_results("select * from ".$wpdb->prefix."term_relationships where term_taxonomy_id='".$term_texonomy_id."'");
								foreach($get_term_relationship as $term_relation_object_id){
										$object_id = $term_relation_object_id->object_id;
										
										$user = get_userdata( $object_id );
										$user_id = $user->ID;
										if(!empty($user_id)){
										$user_fullname = get_user_meta($user_id)['first_name'][0]." ".get_user_meta($user_id)['last_name'][0];
										?>
										<option value="<?php echo $user_id;?>"><?php echo $user_fullname;?></option>
										<?php
										}
									}
								?>
							</select>
						
							</div>
							<div class="form-group">
                                <label for="formGroupExampleInput">Start Time</label>
								<input type="text" name="new_trial_time" class="form-control" readonly/>
							</div>
								
                           <div class="form-group">
                                <label for="formGroupExampleInput">Start Duration</label>
								<input type="text" name="new_trial_duration" class="form-control" readonly/>
						   </div>
                        
                       
                        
                        </div>
						
						</div>
                        <button type="submit" class="btn btn-primary new_trial_button" name="new_trial_button">Start New Trial</button>
                    </div>
                </div>
            </div>
            
			</form>
        </div>
    </body>
	<?php include(dirname(dirname(__FILE__)).'/footer.php'); ?>	
	<script src="<?php echo $plugin_path;?>/assets/js/staff_js/custom.js"></script>
    <script>
	var dashboard_root = {'dashboard_anchor':"<?php echo $plugin_path;?>/dashboards/staff_admin/enrollment_list.php"} 
	var ajax_root = {'ajax_anchor':"<?php echo $plugin_path;?>/assets/lib/staff_ajax/staff.php"} 
	jQuery('#start_class_date').datepicker({
			uiLibrary: 'bootstrap4'
		});
       
    </script>

    </html>