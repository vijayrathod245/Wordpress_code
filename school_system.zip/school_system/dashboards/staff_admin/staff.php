<?php 
include (dirname(dirname(dirname(dirname(dirname(dirname(__FILE__)))))) . '/wp-load.php');

$plugin_name =  plugin_basename(dirname(dirname(dirname( __FILE__ ))));
$plugin_path =  plugins_url().'/'.$plugin_name;

include(dirname(dirname(__FILE__)).'/header.php');

$enrollmet_data = $wpdb->get_results("Select * from ".$wpdb->prefix."ss_enrollment_form where id='".$_REQUEST['enroll_id']."'");
$parent_details = unserialize($enrollmet_data[0]->parent_details);

?>
    <!DOCTYPE html>
    <html>

    <head>
        <title>Staff Admin</title>
        
		<?php ?>
    </head>
    <body>
        <div>
            <h1>Staff</h1></div>
        <div class="container">
		<form id="form_registration" method="post">
		<input type="hidden" name="hid_enrollment_id" value="<?php echo $_REQUEST['enroll_id'];?>"/>
            <div class="student_form">
                <div class="row">
                    <h1>Student Details</h1>
                    <div style="width:100%;">
					
						
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="formGroupExampleInput">First Name</label>
                                <input type="text" class="form-control stu_first_name" name="stu_first_name" placeholder="First name" value="<?php echo unserialize($enrollmet_data[0]->student_details)['student_firstname'];?>"> </div>
                            <div class="form-group col-md-6">
                                <label for="formGroupExampleInput">Last Name</label>
                                <input type="text" class="form-control" name="stu_last_name" placeholder="Last name" value="<?php echo unserialize($enrollmet_data[0]->student_details)['student_lastname'];?>"> </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="formGroupExampleInput">Birthday</label>
                                <input type="text" class="form-control" id="datepicker" name="daterange" value="<?php if(isset(unserialize($enrollmet_data[0]->student_details)['student_birthdate'])){ echo unserialize($enrollmet_data[0]->student_details)['student_birthdate'];}else{ echo "03/03/2020";}?>" placeholder=""> </div>
                            <div class="form-group col-md-6">
                                <label for="formGroupExampleInput">Email</label>
                                <input type="text" class="form-control" name="stu_email" placeholder="Email" value="<?php echo unserialize($enrollmet_data[0]->student_details)['student_email'];?>"> </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="formGroupExampleInput">Phone</label>
                                <input type="text" class="form-control" name="stu_phone" placeholder="Phone" value="<?php echo unserialize($enrollmet_data[0]->student_details)['student_phone'];?>"> </div>
                            <div class="form-group col-md-6">
                                <label for="gender">Select Gender</label>
                                <select class="form-control" name="stu_gender" id="gender">
                                    <option>Select Gender</option>
                                    <option value="male">Male</option>
                                    <option value="female">Female</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="formGroupExampleInput">Address</label>
                                <input type="text" class="form-control" name="stu_address" placeholder="Address" value="<?php echo unserialize($enrollmet_data[0]->student_details)['student_address'];?>"> </div>
                        
                          <?php  /* <div class="form-group col-md-6">
                                <label for="formGroupExampleInput">Class</label>
                                <select class="form-control" name="stu_class" id="gender">
                                    <option>Select Class</option>
                                    <?php
									$class_id = trim(unserialize($enrollmet_data[0]->student_details)['student_class']);
									global $post;
									
										$args = array(
										'post_type' => 'sfwd-courses'
										);
									
									
									$posts = get_posts($args);
									foreach( $posts as $post ) : setup_postdata($post); 
									if(isset($class_id) && $post->ID == $class_id){
									?>
										<option value="<? echo $post->ID; ?>" selected ><?php the_title(); ?></option>
									<?php 
									}else{
									?>
										<option value="<? echo $post->ID; ?>"><?php the_title(); ?></option>
									<?php 
									}
									endforeach; ?>
									</select>
                            </div> */ ?>
                            
                        </div>
						<div class="form-row">
							<?php /* <div class="form-group col-md-6">
							<label for="formGroupExampleInput">Select Teacher</label>
							<select class="form-control" name="stu_teacher" id="stu_teacher">
								<option>Select Teacher</option>
								<?php
								$get_term_role = $wpdb->get_results("select * from ".$wpdb->prefix."terms where name='teacher'");
								$term_id = $get_term_role[0]->term_id;
								$get_term_texomony = $wpdb->get_results("select * from ".$wpdb->prefix."term_taxonomy where term_id='".$term_id."'");
								$term_texonomy_id = $get_term_texomony[0]->term_taxonomy_id;
								$get_term_relationship = $wpdb->get_results("select * from ".$wpdb->prefix."term_relationships where term_taxonomy_id='".$term_texonomy_id."'");
								foreach($get_term_relationship as $term_relation_object_id){
										$object_id = $term_relation_object_id->object_id;
										
										$user = get_userdata( $object_id );
										$user_id = $user->ID;
										if(!empty($user_id)){
										$user_fullname = get_user_meta($user_id)['first_name'][0]."_".get_user_meta($user_id)['last_name'][0];
										?>
										<option value="<?php echo $user_id;?>"><?php echo $user_fullname;?></option>
										<?php
										}
									}
								?>
								</select>
						
							</div> */ ?>
						</div>
                        <button type="button" class="btn btn-primary float-right student_next_button">Next</button>
                    </div>
                </div>
            </div>
            <div class="parent_form" style="display:none;">
                <div class="row">
                    <h1>Parent Details</h1>
                    <div style="width:100%;">
						
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="formGroupExampleInput">First Name</label>
                                <input type="text" class="form-control" name="par_firstname" placeholder="First name" value="<?php echo $parent_details['parent_enrollment_firstname'];?>"> </div>
                            <div class="form-group col-md-6">
                                <label for="formGroupExampleInput">Last Name</label>
                                <input type="text" class="form-control" name="par_lastname" placeholder="Last name" value="<?php echo $parent_details['parent_enrollment_lastname'];?>"> </div>
                        </div>
						<div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="formGroupExampleInput">Email</label>
                                <input type="text" class="form-control" name="par_email" placeholder="Email" value="<?php echo $parent_details['parent_enrollment_email'];?>"> </div>
                        
                            <div class="form-group col-md-6">
                                <label for="formGroupExampleInput">Phone</label>
                                <input type="text" class="form-control" name="par_phone" placeholder="Phone" value="<?php echo $parent_details['parent_enrollment_phone'];?>"> </div>
                        </div>
						<div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="formGroupExampleInput">Address</label>
                                <input type="text" class="form-control" name="par_address" placeholder="Address" value="<?php echo $parent_details['parent_enrollment_address'];?>"> </div>
								 <div class="form-group col-md-6">
									<label for="formGroupExampleInput">Relationship with student</label>
										<select class="form-control" name="par_relationship">
										<option value="">Select</option>
										<option value="father" <?php if($parent_details['parent_enrollment_relationship'] == 'father'){echo 'selected';}?>>Father</option>
										<option value="mother" <?php if($parent_details['parent_enrollment_relationship'] == 'mother'){echo 'selected';}?>>Mother</option>
										<option value="brother" <?php if($parent_details['parent_enrollment_relationship'] == 'brother'){echo 'selected';}?>>Brother</option>
										<option value="sister" <?php if($parent_details['parent_enrollment_relationship'] == 'sister'){echo 'selected';}?>>Sister</option>
										<option value="other" <?php if($parent_details['parent_enrollment_relationship'] == 'other'){echo 'selected';}?>>Others</option>
										</select>
								</div>
                        </div>
						
                        <button type="button" class="btn btn-primary float-left parent_back_button">Back</button>
                        <button type="submit" class="btn btn-primary float-right admission_submit_button" name="admission_submit_button">Submit</button>
                    </div>
                </div>
            </div>
			</form>
        </div>
    </body>
	<?php include(dirname(dirname(__FILE__)).'/footer.php'); ?>	
	<script src="<?php echo $plugin_path;?>/assets/js/staff_js/custom.js"></script>
    <script>
	var dashboard_root = {'dashboard_anchor':"<?php echo $plugin_path;?>/dashboards/staff_admin/enrollment_list.php"} 
	var ajax_root = {'ajax_anchor':"<?php echo $plugin_path;?>/assets/lib/staff_ajax/staff.php"} 
	jQuery('#datepicker').datepicker({
			uiLibrary: 'bootstrap4'
		});
        jQuery(document).ready(function() {
            jQuery('.student_next_button').click(function() {
                jQuery('.parent_form').show();
                jQuery('.student_form').hide();
            });
            jQuery('.parent_back_button').click(function() {
                jQuery('.student_form').show();
                jQuery('.parent_form').hide();
            });
			jQuery('.parent_next_button').click(function() {
                jQuery('.complidata_form').show();
                jQuery('.parent_form').hide();
            });
			jQuery('.complidata_back_button').click(function() {
                jQuery('.complidata_form').hide();
                jQuery('.parent_form').show();
            });
        });
    </script>

    </html>