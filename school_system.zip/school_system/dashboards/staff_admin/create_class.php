<?php 
include (dirname(dirname(dirname(dirname(dirname(dirname(__FILE__)))))) . '/wp-load.php');

$plugin_name =  plugin_basename(dirname(dirname(dirname( __FILE__ ))));
$plugin_path =  plugins_url().'/'.$plugin_name;

include(dirname(dirname(__FILE__)).'/header.php');

global $wpdb;
if(isset($_POST['create_class_button'])){
	global $wpdb;
	$create_class_name = $_POST['create_class_name'];
	$create_class_teacher = $_POST['create_class_teacher'];
	$start_class_date = date('Y-m-d');
	$create_class_time = $_POST['create_class_time'];
	$create_class_duration = $_POST['create_class_duration'];
	
	$insert_class = $wpdb->query("insert into ".$wpdb->prefix."class (id,class_name,class_teacher,class_date,class_time,class_duration) values('','".$create_class_name."','".$create_class_teacher."','".$start_class_date."','".$create_class_time."','".$create_class_duration."')");
		
	/* $wpdb->query("INSERT INTO ".$wpdb->prefix."term_taxonomy (term_taxonomy_id,term_id,taxonomy,description,parent,count) values( '','".$term_id_par."','bp_member_type','','1')");	 */
}

?>
    <!DOCTYPE html>
    <html>

    <head>
        <title>Staff Admin</title>
        
		<?php ?>
    </head>
    <body>
        <div>
            <h1>Staff</h1></div>
        <div class="container">
		<form method="post">
		<input type="hidden" name="hid_enrollment_id" value="<?php echo $_REQUEST['enroll_id'];?>"/>
            <div class="student_form">
                <div class="row">
                    <h1>Add Class</h1>
                    <div style="width:100%;">
					
						
                        
                            <div class="form-group">
                                <label for="formGroupExampleInput">Class/Course Name</label>
                                <input type="text" class="form-control create_class_name" name="create_class_name" placeholder="Class Name" /> </div>
								
							<div class="form-group">
							<label for="formGroupExampleInput">Select Teacher</label>
							<select class="form-control" name="create_class_teacher" id="create_class_teacher">
								<option>Select Teacher</option>
								<?php
								$get_term_role = $wpdb->get_results("select * from ".$wpdb->prefix."terms where name='teacher'");
								$term_id = $get_term_role[0]->term_id;
								$get_term_texomony = $wpdb->get_results("select * from ".$wpdb->prefix."term_taxonomy where term_id='".$term_id."'");
								$term_texonomy_id = $get_term_texomony[0]->term_taxonomy_id;
								$get_term_relationship = $wpdb->get_results("select * from ".$wpdb->prefix."term_relationships where term_taxonomy_id='".$term_texonomy_id."'");
								foreach($get_term_relationship as $term_relation_object_id){
										$object_id = $term_relation_object_id->object_id;
										
										$user = get_userdata( $object_id );
										$user_id = $user->ID;
										if(!empty($user_id)){
										$user_fullname = get_user_meta($user_id)['first_name'][0]." ".get_user_meta($user_id)['last_name'][0];
										?>
										<option value="<?php echo $user_id;?>"><?php echo $user_fullname;?></option>
										<?php
										}
									}
								?>
								</select>
						
							</div> 
                        
                            <?php /* <div class="form-group">
                                <label for="formGroupExampleInput">Start Date</label>
                                <input type="text" class="form-control" id="start_class_date" name="start_class_date" value="03/03/2020" placeholder=""> 
							</div> */ ?>
							<div class="form-group">
                                <label for="formGroupExampleInput">Start Time</label>
								<select class="form-control" name="create_class_time" id="create_class_time">
								<option value="9:00">9:00</option>
								<option value="9:30">9:30</option>
								<option value="10:00">10:00</option>
								<option value="10:30">10:30</option>
								<option value="11:00">11:00</option>
								<option value="11:30">11:30</option>
								<option value="12:00">12:00</option>
								<option value="12:30">12:30</option>
								<option value="1:00">1:00</option>
								<option value="1:30">1:30</option>
								<option value="2:00">2:00</option>
								<option value="2:30">2:30</option>
								<option value="3:00">3:00</option>
								<option value="3:30">3:30</option>
								<option value="4:00">4:00</option>
								<option value="4:30">4:30</option>
								<option value="5:00">5:00</option>
								<option value="5:30">5:30</option>
								<option value="6:00">6:00</option>
								<option value="6:30">6:30</option>
								</select>
							</div>
								
                            <div class="form-group">
                                <label for="formGroupExampleInput">Duration</label>
                                
								<select class="form-control" name="create_class_duration" id="create_class_duration">
									<option value="30">0:30</option>
									<option value="60">1:00</option>
									<option value="90">1:30</option>
									<option value="120">2:00</option>
									<option value="150">2:30</option>
									<option value="180">3:00</option>
								</select>
								</div>
                        
                       
                        
                        </div>
						
						</div>
                        <button type="submit" class="btn btn-primary create_class_button" name="create_class_button">Submit</button>
                    </div>
                </div>
            </div>
            
			</form>
        </div>
    </body>
	<?php include(dirname(dirname(__FILE__)).'/footer.php'); ?>	
	<script src="<?php echo $plugin_path;?>/assets/js/staff_js/custom.js"></script>
    <script>
	var dashboard_root = {'dashboard_anchor':"<?php echo $plugin_path;?>/dashboards/staff_admin/enrollment_list.php"} 
	var ajax_root = {'ajax_anchor':"<?php echo $plugin_path;?>/assets/lib/staff_ajax/staff.php"} 
	jQuery('#start_class_date').datepicker({
			uiLibrary: 'bootstrap4'
		});
       
    </script>

    </html>