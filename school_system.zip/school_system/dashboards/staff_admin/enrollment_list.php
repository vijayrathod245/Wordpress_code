<?php 
include (dirname(dirname(dirname(dirname(dirname(dirname(__FILE__)))))) . '/wp-load.php');
$plugin_name =  plugin_basename(dirname(dirname(dirname( __FILE__ ))));
$plugin_path =  plugins_url().'/'.$plugin_name;

include(dirname(dirname(__FILE__)).'/header.php');
global $wpdb;

$enrollmet_data = $wpdb->get_results("Select * from ".$wpdb->prefix."ss_enrollment_form");



?>
    <html>
   <head>
      <title>Staff Admin</title>
      
   </head>
   <body style="">
      <div class="container">
         <div class="row mt-5">
            <table id="" class="table com-box">
                <thead class="table-head">
                <tr>
                    <tr>
						<th>Sr No.</th>
						<th>Student Name</th>
						<th>Parent Name</th>
						<th>Action</th>
					</tr>
                </tr>
                </thead>
            </div>
                <tbody class="table-content">
				<?php
					$cnt=1;
					foreach($enrollmet_data as $enrollmet_all_data){
						$unser_student_data = unserialize($enrollmet_all_data->student_details);
						$unser_parent_data = unserialize($enrollmet_all_data->parent_details);
						$enrollment_id = $enrollmet_all_data->id;
						$student_enroll_fullname = $unser_student_data['student_firstname']." ".$unser_student_data['student_lastname'];
						$parent_enroll_fullname = $unser_parent_data['parent_enrollment_firstname']." ".$unser_parent_data['parent_enrollment_lastname'];
						?>
						
						 <tr class="staff-table-row">
							<td><?php echo $cnt;?></td>
							<td class="table-left-space"><?php echo $student_enroll_fullname;?></td>
							<td><?php echo $parent_enroll_fullname;?></td>
							<td>
							<?php if($enrollmet_all_data->status == 'yes'){
								?>
								<button disabled type="button" class="btn staff-register-btn enrollment_register_button">Registered<i class="fa fa-sticky-note ml-2" aria-hidden="true"></i></button>
								<?php
							}else{
								?>
								<a href="<?php echo $plugin_path."/dashboards/staff_admin/staff.php?enroll_id=".$enrollmet_all_data->id;?>"><button type="button" class="btn staff-register-btn enrollment_register_button">Register<i class="fa fa-sticky-note ml-2" aria-hidden="true"></i></button></a>
								<?php
							}?>
							</td>
						</tr>
						<?php
						$cnt++;
					}
					
					?>
              
                
                </tbody>
            </table>
         </div>
   

		
   </body>
	 
		
</html>
<?php include(dirname(dirname(__FILE__)).'/footer.php'); ?>	

	<script>
	var ajax_obj = {'ajax_path':"<?php echo $plugin_path;?>"};
		jQuery(document).ready(function() {
		jQuery('#student_enrollment_table').DataTable();
	} );
	</script>