<?php 
include (dirname(dirname(dirname(dirname(dirname(dirname(__FILE__)))))) . '/wp-load.php');
$plugin_name =  plugin_basename(dirname(dirname(dirname( __FILE__ ))));
$plugin_path =  plugins_url().'/'.$plugin_name;

include(dirname(dirname(__FILE__)).'/header.php');
global $wpdb;

$enrollmet_data = $wpdb->get_results("Select * from ".$wpdb->prefix."ss_enrollment_form");

$get_term_role = $wpdb->get_results("select * from ".$wpdb->prefix."terms where name='student'");
$term_id = $get_term_role[0]->term_id;

$get_term_texomony = $wpdb->get_results("select * from ".$wpdb->prefix."term_taxonomy where term_id='".$term_id."'");
$term_texonomy_id = $get_term_texomony[0]->term_taxonomy_id;

$get_term_relationship = $wpdb->get_results("select * from ".$wpdb->prefix."term_relationships where term_taxonomy_id='".$term_texonomy_id."'");


/* die(); */
?>
    <html>
   <head>
      <title>Staff Admin</title>
      
   </head>
   <body style="">
      <div class="container">
         <div class="row mt-5">
            <table id="" class="table com-box">
                <thead class="table-head">
                <tr>
                    <tr>
						<th>Sr No.</th>
						<th>Student Firstname</th>
						<th>Student Lastname</th>
						<th>Student Email</th>
						<th>Student Gender</th>
						<th>Student Phone</th>
						<th>Student Address</th>
						<th>Student Course Name</th>
						<th>Action</th>
					</tr>
                </tr>
                </thead>
            </div>
                <tbody class="table-content">
				<?php
					$cnt=1;
					foreach($get_term_relationship as $term_relation_object_id){
						$object_id = $term_relation_object_id->object_id;

						$user = get_userdata( $object_id );
						$user_id = $user->ID;
						$user_email = $user->user_email;
						if(!empty($user_id)){
						$student_firstname = get_user_meta($user_id)['first_name'][0];
						
						$student_lastname = get_user_meta($user_id)['last_name'][0];
						$student_gender = get_user_meta($user_id)['student_gender'][0];
						$student_phone = get_user_meta($user_id)['student_phone'][0];
						$student_address = get_user_meta($user_id)['student_address'][0];
						$student_course_id = get_user_meta($user_id)['student_course_id'][0];
						/* echo "<pre>";print_r(get_post($student_course_id)); */
						$student_course_name = get_post($student_course_id)->post_title;
						?>
						<tr class="staff-table-row">
							<td><?php echo $cnt;?></td>
							<td class="table-left-space"><?php echo $student_firstname;?></td>
							<td class="table-left-space"><?php echo $student_lastname;?></td>
							<td class="table-left-space"><?php echo $user_email;?></td>
							<td class="table-left-space"><?php echo $student_gender;?></td>
							<td class="table-left-space"><?php echo $student_phone;?></td>
							<td class="table-left-space"><?php echo $student_address;?></td>
							<td class="table-left-space"><?php echo $student_course_name;?></td>
							
							<td>
							
								<button type="button" class="btn staff-register-btn btn-lg" data-toggle="modal" data-target="#update_registered_list<?php echo $user_id;?>">Update<i class="fa fa-sticky-note ml-2" aria-hidden="true"></i></button>
								
								  <!-- Modal -->
								  <div class="modal fade" id="update_registered_list<?php echo $user_id;?>" role="dialog">
									<div class="modal-dialog modal-lg">
									  <div class="modal-content">
										<div class="modal-header">
										  <button type="button" class="close" data-dismiss="modal">&times;</button>
										  <center><h4 class="modal-title">Update Records</h4></center>
										</div>
										<div class="modal-body">
										  <div class="form-group">
											<label for="student_registered_fname">Student Firstname</label>
											<input type="text" class="form-control student_registered_fname<?php echo $user_id;?>" id="student_registered_fname" value="<?php echo $student_firstname;?>">
										  </div><div class="form-group">
											<label for="student_registered_lname">Student Lastname</label>
											<input type="text" class="form-control student_registered_lname<?php echo $user_id;?>" id="student_registered_lname" value="<?php echo $student_lastname;?>">
										  </div>
										  <div class="form-group">
											<label for="student_registered_email">Student Email</label>
											<input type="text" class="form-control student_registered_email<?php echo $user_id;?>" id="student_registered_email" value="<?php echo $user_email;?>">
										  </div>
										  <div class="form-group">
											<label for="student_registered_gender">Student Gender</label>
											<select class="form-control student_registered_gender<?php echo $user_id;?>" name="student_registered_gender" id="student_registered_gender">
											<option value="male" <?php if($student_gender == 'male'){echo 'selected';}?>>Male</option>
											<option value="female" <?php if($student_gender == 'female'){echo 'selected';}?>>Female</option>
											</select>
										  </div>
										  <div class="form-group">
											<label for="student_registered_phone">Student Phone</label>
											<input type="text" class="form-control student_registered_phone<?php echo $user_id;?>" id="student_registered_phone" value="<?php echo $student_phone;?>">
										  </div>
										  <div class="form-group">
											<label for="student_registered_address">Student Address</label>
											<input type="text" class="form-control student_registered_address<?php echo $user_id;?>" id="student_registered_address" value="<?php echo $student_address;?>">
										  </div>
										  <button type="javascript:void(0);" data-id="<?php echo $user_id;?>" class="btn btn-primary update_registered_button">Update</button>
										  
										</div>
										
									  </div>
									</div>
								  </div>
							</td>
						</tr>
						<?php
						}
					
						
						$cnt++;
					}
					
					?>
              
                
                </tbody>
            </table>
         </div>
   

		
   </body>
	 
		
</html>
<?php include(dirname(dirname(__FILE__)).'/footer.php'); ?>	
<script src="<?php echo $plugin_path;?>/assets/js/staff_js/custom.js"></script>
	<script>
	var ajax_root = {'ajax_anchor':"<?php echo $plugin_path;?>/assets/lib/staff_ajax/staff.php"} 
	/* var ajax_root1 = {'ajax_anchor1':"<?php echo $plugin_path;?>"}  */
	var dashboard_root = {'dashboard_anchor':"<?php echo $plugin_path;?>/dashboards/staff_admin/enrollment_list.php"}  
		jQuery(document).ready(function() {
		jQuery('#student_enrollment_table').DataTable();
	} );
	</script>