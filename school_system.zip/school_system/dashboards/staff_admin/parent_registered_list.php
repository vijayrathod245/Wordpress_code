<?php 
include (dirname(dirname(dirname(dirname(dirname(dirname(__FILE__)))))) . '/wp-load.php');
$plugin_name =  plugin_basename(dirname(dirname(dirname( __FILE__ ))));
$plugin_path =  plugins_url().'/'.$plugin_name;

include(dirname(dirname(__FILE__)).'/header.php');
global $wpdb;

$enrollmet_data = $wpdb->get_results("Select * from ".$wpdb->prefix."ss_enrollment_form");

$get_term_role = $wpdb->get_results("select * from ".$wpdb->prefix."terms where name='parent'");
$term_id = $get_term_role[0]->term_id;

$get_term_texomony = $wpdb->get_results("select * from ".$wpdb->prefix."term_taxonomy where term_id='".$term_id."'");
$term_texonomy_id = $get_term_texomony[0]->term_taxonomy_id;

$get_term_relationship = $wpdb->get_results("select * from ".$wpdb->prefix."term_relationships where term_taxonomy_id='".$term_texonomy_id."'");


/* die(); */
?>
    <html>
   <head>
      <title>Staff Admin</title>
      
   </head>
   <body style="">
      <div class="container">
         <div class="row mt-5">
            <table id="" class="table com-box">
                <thead class="table-head">
                <tr>
                    <tr>
						<th>Sr No.</th>
						<th>Parent Firstname</th>
						<th>Parent Lastname</th>
						<th>Parent Email</th>
						<th>Parent Phone</th>
						<th>Parent Address</th>
						<th>Action</th>
					</tr>
                </tr>
                </thead>
            </div>
                <tbody class="table-content">
				<?php
					$cnt=1;
					foreach($get_term_relationship as $term_relation_object_id){
						$object_id = $term_relation_object_id->object_id;

						$user = get_userdata( $object_id );
						$user_id = $user->ID;
						$user_email = $user->user_email;
						if(!empty($user_id)){
						$parent_firstname = get_user_meta($user_id)['first_name'][0];
						$parent_lastname = get_user_meta($user_id)['last_name'][0];
						$parent_phone = get_user_meta($user_id)['parent_phone'][0];
						$parent_address = get_user_meta($user_id)['parent_address'][0];
						?>
						<tr class="staff-table-row">
							<td><?php echo $cnt;?></td>
							<td class="table-left-space"><?php echo $parent_firstname;?></td>
							<td class="table-left-space"><?php echo $parent_lastname;?></td>
							<td class="table-left-space"><?php echo $user_email;?></td>
							<td class="table-left-space"><?php echo $parent_phone;?></td>
							<td class="table-left-space"><?php echo $parent_address;?></td>
							
							<td>
							
								<button type="button" class="btn staff-register-btn btn-lg" data-toggle="modal" data-target="#update_par_registered_list<?php echo $user_id;?>">Update<i class="fa fa-sticky-note ml-2" aria-hidden="true"></i></button>
								
								  <!-- Modal -->
								  <div class="modal fade" id="update_par_registered_list<?php echo $user_id;?>" role="dialog">
									<div class="modal-dialog modal-lg">
									  <div class="modal-content">
										<div class="modal-header">
										  <button type="button" class="close" data-dismiss="modal">&times;</button>
										  <center><h4 class="modal-title">Update Records</h4></center>
										</div>
										<div class="modal-body">
										  <div class="form-group">
											<label for="par_registered_fname">Parent Firstname</label>
											<input type="text" class="form-control par_registered_fname<?php echo $user_id;?>" id="par_registered_fname" value="<?php echo $parent_firstname;?>">
										  </div><div class="form-group">
											<label for="par_registered_lname">Parent Lastname</label>
											<input type="text" class="form-control par_registered_lname<?php echo $user_id;?>" id="par_registered_lname" value="<?php echo $parent_lastname;?>">
										  </div>
										  <div class="form-group">
											<label for="par_registered_email">Parent Email</label>
											<input type="text" class="form-control par_registered_email<?php echo $user_id;?>" id="par_registered_email" value="<?php echo $user_email;?>">
										  </div>
										  <div class="form-group">
											<label for="par_registered_phone">Parent Phone</label>
											<input type="text" class="form-control par_registered_phone<?php echo $user_id;?>" id="par_registered_phone" value="<?php echo $parent_phone;?>">
										  </div>
										  <div class="form-group">
											<label for="par_registered_address">Parent Address</label>
											<input type="text" class="form-control par_registered_address<?php echo $user_id;?>" id="par_registered_address" value="<?php echo $parent_address;?>">
										  </div>
										  <button type="javascript:void(0);" data-id="<?php echo $user_id;?>" class="btn btn-primary update_par_registered_button">Update</button>
										  
										</div>
										
									  </div>
									</div>
								  </div>
							</td>
						</tr>
						<?php
						}
					
						
						$cnt++;
					}
					
					?>
              
                
                </tbody>
            </table>
         </div>
   

		
   </body>
	 
		
</html>
<?php include(dirname(dirname(__FILE__)).'/footer.php'); ?>	
<script src="<?php echo $plugin_path;?>/assets/js/staff_js/custom.js"></script>
	<script>
	var ajax_root = {'ajax_anchor':"<?php echo $plugin_path;?>/assets/lib/staff_ajax/staff.php"} 
	/* var ajax_root1 = {'ajax_anchor1':"<?php echo $plugin_path;?>"}  */
	var dashboard_root = {'dashboard_anchor':"<?php echo $plugin_path;?>/dashboards/staff_admin/enrollment_list.php"}  
		jQuery(document).ready(function() {
		jQuery('#student_enrollment_table').DataTable();
	} );
	</script>