<?php 
	echo "<h1>User</h1>
		<div>User Name</div>
		<div><input type='text' name='user_login'/></div>
		<div>Password</div>
		<div><input type='password' name='user_pass'/></div>
		<div><input type='submit' name='submit' value='Submit'/></div>
	";
?>