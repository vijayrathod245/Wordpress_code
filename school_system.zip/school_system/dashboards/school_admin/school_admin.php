<?php 
include (dirname(dirname(dirname(dirname(dirname(dirname(__FILE__)))))) . '/wp-load.php');
$plugin_name =  plugin_basename(dirname(dirname(dirname( __FILE__ ))));
$plugin_path =  plugins_url().'/'.$plugin_name;
$user_id =  get_current_user_id();
include(dirname(dirname(__FILE__)).'/header.php');




if($_POST['submit']){
	global $wpdb;
	$teacher_firstname = $_POST['teacher_firstname'];
	$teacher_lastname = $_POST['teacher_lastname']; 
	$teacher_daterange = $_POST['teacher_daterange'];
	$teacher_email = $_POST['teacher_email'];
	$teacher_phone = $_POST['teacher_phone'];
	$teacher_gender = $_POST['teacher_gender'];
	/* $username = ;
	$user_pass = md5($_POST['user_pass']); */
	$teacher_address = $_POST['teacher_address'];
	$teacher_fullname = strtolower($teacher_firstname."_".$teacher_lastname);
	
	$teacherdata = array(
    'user_login'             => $teacher_fullname,
    'user_pass'            => md5('/){:}('.$teacher_fullname),
    'user_nicename'         => $teacher_fullname,
    'user_email'            => $teacher_email,
    'display_name'          => $teacher_fullname,
	'first_name'     => $teacher_firstname,
	'last_name'      => $teacher_lastname
	);
	/* $teacher_id = '25'; */
	$teacher_id = wp_insert_user( $teacherdata );
	
	add_user_meta($teacher_id,'teacher_firstname',$teacher_firstname);
	add_user_meta($teacher_id,'teacher_firstname',$teacher_firstname);
	add_user_meta($teacher_id,'teacher_lastname',$teacher_lastname);
	add_user_meta($teacher_id,'teacher_lastname',$teacher_lastname);
	add_user_meta($teacher_id,'teacher_gender',$teacher_gender);
	add_user_meta($teacher_id,'teacher_phone',$teacher_phone);
	add_user_meta($teacher_id,'teacher_birthdate',$teacher_daterange);
	add_user_meta($teacher_id,'teacher_address',$teacher_address);


	if(!empty($teacher_id)){
		$get_term_role = $wpdb->get_results("select * from ".$wpdb->prefix."terms where name='teacher'");
		$term_id = $get_term_role[0]->term_id."<br/>";
		
		$get_term_texomony = $wpdb->get_results("select * from ".$wpdb->prefix."term_taxonomy where term_id='".$term_id."'");
		$total_cnt = $get_term_texomony[0]->count+1;
		
		if(sizeof($get_term_texomony)>0){
			$update_term_taxonomy = $wpdb->query("UPDATE ".$wpdb->prefix."term_taxonomy set count='".$total_cnt."' where term_taxonomy_id='".$get_term_texomony[0]->term_taxonomy_id."'");
			 $term_taxo = $get_term_texomony[0]->term_taxonomy_id."<br/>";
			
		}else{
			$insert_term = $wpdb->query("INSERT INTO ".$wpdb->prefix."term_taxonomy (term_taxonomy_id,term_id,taxonomy,description,parent,count) values( '','".$term_id."','bp_member_type','','1')");
			
			$term_taxo = $insert_term->term_taxonomy_id;
		}
		/* echo 'here'."</br>"; */
		 $insert_term_relationships = $wpdb->query("INSERT INTO ".$wpdb->prefix."term_relationships (object_id,term_taxonomy_id,term_order) values( '".$teacher_id."','".$term_taxo."','')");
		 
	}
}

?>
    <head>
        <title>School Admin</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
        <script type="text/javascript" src="https://cdn.jsdelivr.net/jquery/latest/jquery.min.js"></script>
        <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
        <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
        <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
        <script src="<?php echo $plugin_path;?>/assets/js/jquery.min.js"></script> 
		<script src="<?php echo $plugin_path;?>/assets/js/bootstrap.js"> </script>
		<script src="<?php echo $plugin_path;?>/assets/js/bootstrap.min.js"></script>
		<script src="<?php echo $plugin_path;?>/assets/js/all.min.js"></script>
		<script src="<?php echo $plugin_path;?>/assets/js/fontawesome.min.js"></script>
		<script src="<?php echo $plugin_path;?>/assets/js/costom.js"></script>
		<script src="<?php echo $plugin_path;?>/assets/js/gijgo.min.js"></script>

	</head>
	<body>
        <div>
            <h1>School Admin</h1></div>
        <div class="container">
            <div class="student_form">
                <div class="row">
                    <h1>Add Teacher</h1>
                    <form style="width:100%;" method="post">
					
						
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="formGroupExampleInput">First Name</label>
                                <input type="text" class="form-control" name="teacher_firstname"> </div> 
                            <div class="form-group col-md-6">
                                <label for="formGroupExampleInput">Last Name</label>
                                <input type="text" class="form-control" name="teacher_lastname"> </div>
                        </div>
                        <div class="form-row">
                            <div class="col-md-6">
								<label for="formGroupExampleInput">Birth Date</label>
								<input id="datepicker" class="input" name="teacher_daterange"/>
								<!-- <input type="date" class="form-control" name=""> -->
							</div>
                            <div class="form-group col-md-6">
                                <label for="formGroupExampleInput">Email</label>
                                <input type="email" class="form-control" name="teacher_email"> </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="formGroupExampleInput">Phone</label>
                                <input type="text" class="form-control" name="teacher_phone"> </div>
                            <div class="form-group col-md-6">
                                <label for="gender">Select Gender</label>
                                <select class="form-control" name="teacher_gender" id="gender">
                                    <option>Select Gender</option>
                                    <option>Male</option>
                                    <option>Female</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group col-md-12">
                                <label for="formGroupExampleInput">Address</label>
                                <input type="text" class="form-control" name="teacher_address"> </div>
                            
                        </div>
                        <input type="submit" name="submit" class="btn btn-primary float-right" value="Submit" />
                    </form>
                </div>
            </div>
            
			
        </div>
    </body>
    <script>
	jQuery('#datepicker').datepicker({
		uiLibrary: 'bootstrap4'
	});
</script>
<?php include(dirname(dirname(__FILE__)).'/footer.php'); ?>	