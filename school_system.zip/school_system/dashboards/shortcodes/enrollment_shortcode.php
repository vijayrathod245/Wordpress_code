<link rel="stylesheet" href="<?php echo $plugin_path;?>/assets/css/bootstrap.css">
<link rel="stylesheet" href="<?php echo $plugin_path;?>/assets/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo $plugin_path;?>/assets/css/style.css">
<link rel="stylesheet" href="<?php echo $plugin_path;?>/assets/css/common.css">
<link rel="stylesheet" href="<?php echo $plugin_path;?>/assets/css/responsive.css">
<link rel="stylesheet" href="<?php echo $plugin_path;?>/assets/css/fontawesome.min.css">
<link rel="stylesheet" href="<?php echo $plugin_path;?>/assets/css/font.css">
<link rel="stylesheet" href="<?php echo $plugin_path;?>/assets/css/all.min.css">
<link rel="stylesheet" href="<?php echo $plugin_path;?>/assets/css/gijgo.min.css"> 

<form method="post">
	<div class="container mt-5 p-3 com-box details-background">
		<h4>Student Details</h4>
		<div class="row row-padding">
		<div class="col-md-6">
			<h6 class="m-0 form-lable">First Name</h6>
			<input type="text" class="form-control stu_first_name" name="stu_first_name">
		</div>
		<div class="col-md-6">
			<h6 class="m-0 form-lable">Last Name</h6>
			<input type="text" class="form-control" name="stu_last_name">
		</div>
		<div class="col-md-6">
			<h6 class="m-0 form-lable">Birth Date</h6>
			<input id="datepicker" class="input" name="daterange" placeholder="Select Date"/>
			<!-- <input type="date" class="form-control" name=""> -->
		</div>
		<div class="col-md-6">
			<h6 class="m-0 form-lable">Email</h6>
			<input type="text" class="form-control" name="stu_email">
		</div>
		<div class="col-md-6">
			<h6 class="m-0 form-lable">Phone</h6>
			<input type="text" class="form-control" name="stu_phone">
		</div>
		<?php /* <div class="col-md-6">
			<h6 class="m-0 form-lable">Course</h6>
			<select class="form-control" name="stu_class">
				<option>Select Course</option>
				<?php									
				global $post;									
				$args = array(										
				'post_type' => 'sfwd-courses'								
				);									
				$posts = get_posts($args);									
				foreach( $posts as $post ) : setup_postdata($post); ?>									
				<option value="<? echo $post->ID; ?>"><?php the_title(); ?></option>				
				<?php endforeach; ?>
			</select>
		</div>  */?>
		<div class="col-12">
			<h6 class="m-0 form-lable">Address</h6>
			<textarea rows="2" class="form-control" name="stu_address"></textarea>
		</div>
		</div>
		<h4 class="pt-5">Parent Details</h4>
		<div class="row row-padding">
			<div class="col-md-6">
				<h6 class="m-0 form-lable">First Name</h6>
				<input type="text" class="form-control" name="par_firstname">
			</div>
			<div class="col-md-6">
				<h6 class="m-0 form-lable">Last Name</h6>
				<input type="text" class="form-control" name="par_lastname">
			</div>
			<div class="col-md-6">
				<h6 class="m-0 form-lable">Phone</h6>
				<input type="text" class="form-control" name="par_phone">
			</div>
			<div class="col-md-6">
				<h6 class="m-0 form-lable">Email</h6>
				<input type="text" class="form-control" name="par_email">
			</div>
			<div class="col-md-6">
				<h6 class="m-0 form-lable">Relationship with student</h6>
                    <select class="form-control" name="par_relationship">
                    <option value="">Select</option>
                    <option value="father">Father</option>
                    <option value="mother">Mother</option>
                    <option value="brother">Brother</option>
                    <option value="sister">Sister</option>
                    <option value="other">Others</option>
                    </select>
			</div>
			<div class="col-12">
				<h6 class="m-0 form-lable">Address</h6>
				<textarea rows="2" class="form-control" name="par_address"></textarea>
			</div>
		</div>
		
		<div class="text-center mt-4">
			<button class="custom-btn form-submit-btn" name="submit_enrollment_form">Submit</button>
		</div>
	</div>
</form>
<script src="<?php echo $plugin_path;?>/assets/js/jquery.min.js"></script> 
<script src="<?php echo $plugin_path;?>/assets/js/bootstrap.js"> </script>
<script src="<?php echo $plugin_path;?>/assets/js/bootstrap.min.js"></script>
<script src="<?php echo $plugin_path;?>/assets/js/all.min.js"></script>
<script src="<?php echo $plugin_path;?>/assets/js/fontawesome.min.js"></script>
<script src="<?php echo $plugin_path;?>/assets/js/costom.js"></script>
<script src="<?php echo $plugin_path;?>/assets/js/gijgo.min.js"></script>
<script>
	jQuery('#datepicker').datepicker({
		uiLibrary: 'bootstrap4'
	});
</script>
			<?php
			global $wpdb;
			if(isset($_POST['submit_enrollment_form'])){
				
				global $wpdb;
				/** Student Enrollement Form **/
				$stu_enrollment_firstname = $_POST['stu_first_name'];
				$stu_enrollment_lastname = $_POST['stu_last_name'];
				$stu_enrollment_birthdate = $_POST['daterange'];
				$stu_enrollment_email = $_POST['stu_email'];
				$stu_enrollment_address = $_POST['stu_address'];
				/* $stu_enrollment_class = $_POST['stu_class']; */
				$stu_enrollment_phone = $_POST['stu_phone'];
				$serialized_student_enrolldata = serialize(
				array("student_firstname"=>$stu_enrollment_firstname, 
				"student_lastname"=>$stu_enrollment_lastname, 
				"student_birthdate"=>$stu_enrollment_birthdate,
				"student_email"=>$stu_enrollment_email,
				"student_address"=>$stu_enrollment_address,
				/* "student_class"=>$stu_enrollment_class, */
				"student_phone"=>$stu_enrollment_phone)
				);
				
				
				/** Parent Enrollement Form **/
				$parent_enrollment_firstname = $_POST['par_firstname'];
				$parent_enrollment_lastname = $_POST['par_lastname'];
				$parent_enrollment_email = $_POST['par_email'];
				$parent_enrollment_phone = $_POST['par_phone'];
				$parent_enrollment_address = $_POST['par_address'];
				$parent_enrollment_relationship = $_POST['par_relationship'];
				$serialized_parent_enrolldata = serialize(
				array(
					"parent_enrollment_firstname"=>$parent_enrollment_firstname, 
					"parent_enrollment_lastname"=>$parent_enrollment_lastname, 
					"parent_enrollment_email"=>$parent_enrollment_email,
					"parent_enrollment_phone"=>$parent_enrollment_phone,
					"parent_enrollment_address"=>$parent_enrollment_address,
					"parent_enrollment_relationship"=>$parent_enrollment_relationship)
				);
				/* echo "<pre>";print_r($serialized_student_enrolldata);
				echo "<pre>";print_r($serialized_parent_enrolldata);die(); */
				$insert_enrollment = $wpdb->query("INSERT INTO ".$wpdb->prefix."ss_enrollment_form (id,student_details,parent_details,status) values( '','".$serialized_student_enrolldata."','".$serialized_parent_enrolldata."','no')");
				
			}
			
			?>
			