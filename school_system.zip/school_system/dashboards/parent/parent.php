<?php include(dirname(dirname(dirname(dirname(dirname(__FILE__))))).'/wp-load.php');
	echo "<h1>Parent</h1>";
	$user_id =  get_current_user_id();
	echo "<pre>";print_r(get_userdata( $user_id ));
?>